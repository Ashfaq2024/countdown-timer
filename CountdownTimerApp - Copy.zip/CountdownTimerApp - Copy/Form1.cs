﻿using System;
using System.Windows.Forms;

namespace CountdownTimerApp
{
    public partial class Form1 : Form
    {
        private int remainingTime; // Variable to store the remaining time in seconds

        public Form1()
        {
            InitializeComponent();

            // Manually initialize the timer if it's not done by the designer
            if (timerCountdown == null)
            {
                timerCountdown = new System.Windows.Forms.Timer();
                timerCountdown.Interval = 1000; // Set interval to 1 second
                timerCountdown.Tick += TimerCountdown_Tick; // Attach the Tick event handler
            }
        }

        private void TimerCountdown_Tick(object sender, EventArgs e)
        {
            if (remainingTime > 0)
            {
                remainingTime--; // Decrement the remaining time
                UpdateTimerDisplay(); // Update the label
            }
            else
            {
                timerCountdown.Stop(); // Stop the timer when it reaches 0
                MessageBox.Show("Time's up!"); // Show a message when the countdown ends
            }
        }

        private void UpdateTimerDisplay()
        {
            // Format the remaining time as minutes and seconds
            int minutes = remainingTime / 60;
            int seconds = remainingTime % 60;
            lblTimer.Text = $"{minutes:D2}:{seconds:D2}";
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtStartTime.Text, out int startTime) && startTime > 0)
            {
                remainingTime = startTime; // Set the remaining time
                UpdateTimerDisplay(); // Update the label
                timerCountdown.Start(); // Start the timer
            }
            else
            {
                MessageBox.Show("Please enter a valid number of seconds."); // Show error message
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            timerCountdown.Stop(); // Stop the timer
            remainingTime = 0; // Reset the remaining time
            UpdateTimerDisplay(); // Update the label
        }
    }
}